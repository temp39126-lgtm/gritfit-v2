
<?php
session_start();

// Only allow an authenticated admin to view diagnostics.
if (empty($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('Forbidden');
}

$log = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
    . DIRECTORY_SEPARATOR
    . 'gritfit-admin-diagnostic.log';

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

if (!is_file($log)) {
    exit('No diagnostic log found. Check that the diagnostic file is included and writable.');
}

echo file_get_contents($log);
