
<?php
// TEMPORARY ADMIN SAVE DIAGNOSTICS
// Writes to the system temporary directory, not public_html.

$diagnosticLog = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
    . DIRECTORY_SEPARATOR
    . 'gritfit-admin-diagnostic.log';

$GLOBALS['gritfit_diag_log'] = $diagnosticLog;
$GLOBALS['gritfit_diag_action'] = $_POST['action'] ?? 'no_post_action';

function gritfit_diag_write($message) {
    $log = $GLOBALS['gritfit_diag_log'] ?? '';

    if ($log !== '') {
        @file_put_contents(
            $log,
            '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    gritfit_diag_write(
        'POST STARTED | action=' .
        preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$GLOBALS['gritfit_diag_action'])
    );
}

// Capture uncaught exceptions, including database exceptions.
set_exception_handler(function ($e) {
    gritfit_diag_write(
        'UNCAUGHT EXCEPTION: ' . get_class($e) .
        ' | Message: ' . $e->getMessage() .
        ' | File: ' . $e->getFile() .
        ' | Line: ' . $e->getLine() .
        ' | Action: ' . ($GLOBALS['gritfit_diag_action'] ?? 'unknown') .
        ' | Trace: ' . $e->getTraceAsString()
    );

    http_response_code(500);
    echo 'A server error occurred. Check the temporary diagnostic log.';
});

// Capture fatal errors that stop PHP execution.
register_shutdown_function(function () {
    $error = error_get_last();

    if ($error && in_array($error['type'], [
        E_ERROR,
        E_PARSE,
        E_CORE_ERROR,
        E_COMPILE_ERROR,
        E_USER_ERROR,
        E_RECOVERABLE_ERROR
    ], true)) {
        gritfit_diag_write(
            'FATAL ERROR: ' . $error['message'] .
            ' | File: ' . $error['file'] .
            ' | Line: ' . $error['line'] .
            ' | Action: ' . ($GLOBALS['gritfit_diag_action'] ?? 'unknown')
        );
    }
});
