<?php
$reviews = cms_rows('reviews');
$whatsapp = setting('contact_whatsapp');
$socials = [
    'facebook' => setting('social_facebook'),
    'instagram' => setting('social_instagram'),
    'twitter' => setting('social_twitter'),
];
if (empty($socialSvg)) {
    $socialSvg = [
        'facebook' => '<path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>',
        'instagram' => '<path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>',
        'twitter' => '<path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>',
    ];
}
?>

<?php if (cms_flag('reviews_enabled') && !empty($reviews) && $page !== 'contact'): ?>
<section class="section reviews-section">
    <div class="container">
        <div class="reviews-header">
            <h3><?= e(setting('reviews_title')) ?></h3>
            <?php if (setting('reviews_subtitle')): ?><p><?= e(setting('reviews_subtitle')) ?></p><?php endif; ?>
        </div>
        <div class="reviews-grid">
            <?php foreach ($reviews as $rev): ?>
            <div class="review-card">
                <div class="stars"><?= str_repeat('★', (int)$rev['rating']) ?></div>
                <p><?= e($rev['review_text']) ?></p>
                <?php if (!empty($rev['answer'])): ?>
                <div class="review-reply"><strong>Reply from <?= e(setting('site_name')) ?>:</strong> <?= e($rev['answer']) ?></div>
                <?php endif; ?>
                <div class="review-author">
                    <?php if ($rev['avatar']): ?><img src="<?= e(asset_url($rev['avatar'])) ?>" alt="<?= e($rev['name']) ?>"><?php endif; ?>
                    <div>
                        <h6><?= e($rev['name']) ?></h6>
                        <span><?= e($rev['location']) ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php render_banner_slider('bottom'); /* banners assigned to the "Bottom" position */ ?>

<?php if (cms_flag('bottombanner_enabled') && setting('bottombanner_title')):
    $bbImg = setting('bottombanner_image');
    $bbStyle = $bbImg ? ' style="background-image:linear-gradient(rgba(13,20,26,0.7),rgba(13,20,26,0.7)),url(\'' . e(asset_url($bbImg)) . '\');background-size:cover;background-position:center;"' : '';
?>
<section class="bottom-banner"<?= $bbStyle ?>>
    <div class="container">
        <h2><?= e(setting('bottombanner_title')) ?></h2>
        <?php if (setting('bottombanner_text')): ?><p><?= e(setting('bottombanner_text')) ?></p><?php endif; ?>
        <?php if (setting('bottombanner_btn_text')): ?>
        <a href="<?= e(link_url(setting('bottombanner_btn_link'))) ?>" class="btn btn-primary"><?= e(setting('bottombanner_btn_text')) ?></a>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

    <?php if ($whatsapp): ?>
    <a href="https://wa.me/<?= e($whatsapp) ?>?text=Hi%20<?= rawurlencode(setting('site_name')) ?>%2C%20I%27m%20interested%20in%20your%20products" class="whatsapp-float" target="_blank" rel="noopener">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </a>
    <?php endif; ?>

    <?php if (cms_flag('footer_enabled')): ?>
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <h5><?= e(setting('site_name')) ?></h5>
                    <p class="tagline"><?= e(setting('site_tagline')) ?></p>
                    <div class="footer-social">
                        <?php foreach ($socials as $key => $url): if (!$url) continue; ?>
                        <a href="<?= e($url) ?>" target="_blank" rel="noopener" title="<?= e(ucfirst($key)) ?>">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><?= $socialSvg[$key] ?></svg>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <p class="footer-copy"><?= e(setting('footer_copy')) ?></p>
                </div>
                <div class="footer-contact">
                    <h5>Contact Us</h5>
                    <?php if (setting('contact_phone')): ?><a href="tel:<?= e(str_replace(' ', '', setting('contact_phone'))) ?>"><?= e(setting('contact_phone')) ?></a><?php endif; ?>
                    <?php if (setting('contact_email')): ?>
                    <a href="<?= e(link_url('/contact#contact-form')) ?>"><?= e(setting('contact_email')) ?></a>
                    <span style="display:block;font-size:12px;opacity:0.65;margin-top:4px;">Tap email to open the contact form</span>
                    <?php endif; ?>
                    <?php if (setting('contact_address')): ?><p style="margin-top:12px;"><?= e(setting('contact_address')) ?></p><?php endif; ?>
                </div>
                <?php if (cms_flag('footer_newsletter_enabled')): ?>
                <div class="footer-newsletter">
                    <h5><?= e(strtoupper(setting('site_name'))) ?></h5>
                    <p>Enter your email address</p>
                    <form class="newsletter-form" onsubmit="alert('Thank you for subscribing!');this.reset();return false;">
                        <input type="email" placeholder="Your email for updates" required>
                        <button type="submit">Subscribe for exclusive offers</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </footer>
    <?php endif; ?>

    <script src="/js/main.js"></script>
</body>
</html>
